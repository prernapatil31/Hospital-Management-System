package com.Hospitalsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
